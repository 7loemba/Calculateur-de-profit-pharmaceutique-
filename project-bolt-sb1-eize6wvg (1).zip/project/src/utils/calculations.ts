import { Medication } from '../types/medication';

export const calculateMedicationProfits = (
  prixGros: number,
  nbPlaquettesCarton: number,
  prixVentePlaquette: number
): Pick<Medication, 'prixAchatPlaquette' | 'beneficePlaquette' | 'beneficeCarton'> => {
  const prixAchatPlaquette = prixGros / nbPlaquettesCarton;
  const beneficePlaquette = prixVentePlaquette - prixAchatPlaquette;
  const beneficeCarton = beneficePlaquette * nbPlaquettesCarton;

  return {
    prixAchatPlaquette,
    beneficePlaquette,
    beneficeCarton,
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
};