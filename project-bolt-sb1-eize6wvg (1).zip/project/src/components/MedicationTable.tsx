import React, { useState } from 'react';
import { Edit2, Trash2, Search, Download } from 'lucide-react';
import { Medication } from '../types/medication';
import { formatCurrency } from '../utils/calculations';

interface MedicationTableProps {
  medications: Medication[];
  onEditMedication: (medication: Medication) => void;
  onDeleteMedication: (id: string) => void;
}

export const MedicationTable: React.FC<MedicationTableProps> = ({
  medications,
  onEditMedication,
  onDeleteMedication,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredMedications = medications.filter(med =>
    med.produit.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalBeneficeCartons = filteredMedications.reduce((sum, med) => sum + med.beneficeCarton, 0);

  const exportToCSV = () => {
    const headers = [
      'Produit',
      'Prix de gros (FCFA)',
      'Nb plaquettes par carton',
      'Prix achat / plaquette (FCFA)',
      'Prix vente / plaquette (FCFA)',
      'Bénéfice / plaquette (FCFA)',
      'Bénéfice / carton (FCFA)'
    ];

    const csvContent = [
      headers.join(','),
      ...filteredMedications.map(med => [
        `"${med.produit}"`,
        med.prixGros,
        med.nbPlaquettesCarton,
        med.prixAchatPlaquette.toFixed(2),
        med.prixVentePlaquette,
        med.beneficePlaquette.toFixed(2),
        med.beneficeCarton.toFixed(2)
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'calcul_benefices_medicaments.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-xl font-semibold text-gray-800">
            Tableau de calcul des bénéfices
          </h2>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <div className="relative">
              <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Rechercher un produit..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
              />
            </div>
            <button
              onClick={exportToCSV}
              className="px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors duration-200 flex items-center gap-2"
            >
              <Download size={16} />
              Exporter CSV
            </button>
          </div>
        </div>
      </div>

      {filteredMedications.length === 0 ? (
        <div className="p-8 text-center text-gray-500">
          {searchTerm ? 'Aucun médicament trouvé pour cette recherche.' : 'Aucun médicament ajouté.'}
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Produit
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prix de gros
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Plaquettes/carton
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prix achat/plaquette
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prix vente/plaquette
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bénéfice/plaquette
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bénéfice/carton
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredMedications.map((medication) => (
                  <tr key={medication.id} className="hover:bg-gray-50 transition-colors duration-150">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{medication.produit}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="text-sm text-gray-900">{formatCurrency(medication.prixGros)} FCFA</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="text-sm text-gray-900">{medication.nbPlaquettesCarton}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="text-sm text-gray-900">{formatCurrency(medication.prixAchatPlaquette)} FCFA</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="text-sm text-gray-900">{formatCurrency(medication.prixVentePlaquette)} FCFA</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className={`text-sm font-semibold ${
                        medication.beneficePlaquette >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {formatCurrency(medication.beneficePlaquette)} FCFA
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className={`text-sm font-semibold ${
                        medication.beneficeCarton >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {formatCurrency(medication.beneficeCarton)} FCFA
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex justify-center gap-2">
                        <button
                          onClick={() => onEditMedication(medication)}
                          className="p-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors duration-150"
                          title="Modifier"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => onDeleteMedication(medication.id)}
                          className="p-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded transition-colors duration-150"
                          title="Supprimer"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600">
                {filteredMedications.length} médicament{filteredMedications.length > 1 ? 's' : ''}
              </span>
              <div className="text-right">
                <span className="text-gray-600">Bénéfice total (cartons): </span>
                <span className={`font-bold ${totalBeneficeCartons >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(totalBeneficeCartons)} FCFA
                </span>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};