import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Medication } from '../types/medication';
import { calculateMedicationProfits } from '../utils/calculations';

interface MedicationFormProps {
  onAddMedication: (medication: Omit<Medication, 'id'>) => void;
}

export const MedicationForm: React.FC<MedicationFormProps> = ({ onAddMedication }) => {
  const [formData, setFormData] = useState({
    produit: '',
    prixGros: '',
    nbPlaquettesCarton: '',
    prixVentePlaquette: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.produit.trim()) {
      newErrors.produit = 'Le nom du produit est requis';
    }

    if (!formData.prixGros || Number(formData.prixGros) <= 0) {
      newErrors.prixGros = 'Le prix de gros doit être supérieur à 0';
    }

    if (!formData.nbPlaquettesCarton || Number(formData.nbPlaquettesCarton) <= 0) {
      newErrors.nbPlaquettesCarton = 'Le nombre de plaquettes doit être supérieur à 0';
    }

    if (!formData.prixVentePlaquette || Number(formData.prixVentePlaquette) <= 0) {
      newErrors.prixVentePlaquette = 'Le prix de vente doit être supérieur à 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    const prixGros = Number(formData.prixGros);
    const nbPlaquettesCarton = Number(formData.nbPlaquettesCarton);
    const prixVentePlaquette = Number(formData.prixVentePlaquette);

    const calculations = calculateMedicationProfits(
      prixGros,
      nbPlaquettesCarton,
      prixVentePlaquette
    );

    const newMedication: Omit<Medication, 'id'> = {
      produit: formData.produit.trim(),
      prixGros,
      nbPlaquettesCarton,
      prixVentePlaquette,
      ...calculations,
    };

    onAddMedication(newMedication);

    // Reset form
    setFormData({
      produit: '',
      prixGros: '',
      nbPlaquettesCarton: '',
      prixVentePlaquette: '',
    });
    setErrors({});
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center gap-2">
        <Plus size={24} className="text-blue-600" />
        Ajouter un médicament
      </h2>
      
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label htmlFor="produit" className="block text-sm font-medium text-gray-700 mb-1">
            Nom du produit
          </label>
          <input
            type="text"
            id="produit"
            value={formData.produit}
            onChange={(e) => handleInputChange('produit', e.target.value)}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
              errors.produit ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="Ex: Ibucap forte"
          />
          {errors.produit && <p className="text-red-500 text-xs mt-1">{errors.produit}</p>}
        </div>

        <div>
          <label htmlFor="prixGros" className="block text-sm font-medium text-gray-700 mb-1">
            Prix de gros (FCFA)
          </label>
          <input
            type="number"
            id="prixGros"
            value={formData.prixGros}
            onChange={(e) => handleInputChange('prixGros', e.target.value)}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
              errors.prixGros ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="2500"
            min="0"
            step="0.01"
          />
          {errors.prixGros && <p className="text-red-500 text-xs mt-1">{errors.prixGros}</p>}
        </div>

        <div>
          <label htmlFor="nbPlaquettes" className="block text-sm font-medium text-gray-700 mb-1">
            Plaquettes par carton
          </label>
          <input
            type="number"
            id="nbPlaquettes"
            value={formData.nbPlaquettesCarton}
            onChange={(e) => handleInputChange('nbPlaquettesCarton', e.target.value)}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
              errors.nbPlaquettesCarton ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="10"
            min="1"
          />
          {errors.nbPlaquettesCarton && <p className="text-red-500 text-xs mt-1">{errors.nbPlaquettesCarton}</p>}
        </div>

        <div>
          <label htmlFor="prixVente" className="block text-sm font-medium text-gray-700 mb-1">
            Prix vente/plaquette (FCFA)
          </label>
          <input
            type="number"
            id="prixVente"
            value={formData.prixVentePlaquette}
            onChange={(e) => handleInputChange('prixVentePlaquette', e.target.value)}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
              errors.prixVentePlaquette ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="400"
            min="0"
            step="0.01"
          />
          {errors.prixVentePlaquette && <p className="text-red-500 text-xs mt-1">{errors.prixVentePlaquette}</p>}
        </div>

        <div className="md:col-span-2 lg:col-span-4">
          <button
            type="submit"
            className="w-full md:w-auto px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200 flex items-center justify-center gap-2"
          >
            <Plus size={20} />
            Ajouter le médicament
          </button>
        </div>
      </form>
    </div>
  );
};