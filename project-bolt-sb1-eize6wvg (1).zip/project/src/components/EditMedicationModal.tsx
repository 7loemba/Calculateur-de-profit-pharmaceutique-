import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { Medication } from '../types/medication';
import { calculateMedicationProfits } from '../utils/calculations';

interface EditMedicationModalProps {
  medication: Medication | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (medication: Medication) => void;
}

export const EditMedicationModal: React.FC<EditMedicationModalProps> = ({
  medication,
  isOpen,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState({
    produit: '',
    prixGros: '',
    nbPlaquettesCarton: '',
    prixVentePlaquette: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (medication) {
      setFormData({
        produit: medication.produit,
        prixGros: medication.prixGros.toString(),
        nbPlaquettesCarton: medication.nbPlaquettesCarton.toString(),
        prixVentePlaquette: medication.prixVentePlaquette.toString(),
      });
    }
  }, [medication]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.produit.trim()) {
      newErrors.produit = 'Le nom du produit est requis';
    }

    if (!formData.prixGros || Number(formData.prixGros) <= 0) {
      newErrors.prixGros = 'Le prix de gros doit être supérieur à 0';
    }

    if (!formData.nbPlaquettesCarton || Number(formData.nbPlaquettesCarton) <= 0) {
      newErrors.nbPlaquettesCarton = 'Le nombre de plaquettes doit être supérieur à 0';
    }

    if (!formData.prixVentePlaquette || Number(formData.prixVentePlaquette) <= 0) {
      newErrors.prixVentePlaquette = 'Le prix de vente doit être supérieur à 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !medication) return;

    const prixGros = Number(formData.prixGros);
    const nbPlaquettesCarton = Number(formData.nbPlaquettesCarton);
    const prixVentePlaquette = Number(formData.prixVentePlaquette);

    const calculations = calculateMedicationProfits(
      prixGros,
      nbPlaquettesCarton,
      prixVentePlaquette
    );

    const updatedMedication: Medication = {
      ...medication,
      produit: formData.produit.trim(),
      prixGros,
      nbPlaquettesCarton,
      prixVentePlaquette,
      ...calculations,
    };

    onSave(updatedMedication);
    onClose();
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!isOpen || !medication) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">Modifier le médicament</h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded transition-colors duration-150"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label htmlFor="edit-produit" className="block text-sm font-medium text-gray-700 mb-1">
              Nom du produit
            </label>
            <input
              type="text"
              id="edit-produit"
              value={formData.produit}
              onChange={(e) => handleInputChange('produit', e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                errors.produit ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.produit && <p className="text-red-500 text-xs mt-1">{errors.produit}</p>}
          </div>

          <div>
            <label htmlFor="edit-prixGros" className="block text-sm font-medium text-gray-700 mb-1">
              Prix de gros (FCFA)
            </label>
            <input
              type="number"
              id="edit-prixGros"
              value={formData.prixGros}
              onChange={(e) => handleInputChange('prixGros', e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                errors.prixGros ? 'border-red-500' : 'border-gray-300'
              }`}
              min="0"
              step="0.01"
            />
            {errors.prixGros && <p className="text-red-500 text-xs mt-1">{errors.prixGros}</p>}
          </div>

          <div>
            <label htmlFor="edit-nbPlaquettes" className="block text-sm font-medium text-gray-700 mb-1">
              Plaquettes par carton
            </label>
            <input
              type="number"
              id="edit-nbPlaquettes"
              value={formData.nbPlaquettesCarton}
              onChange={(e) => handleInputChange('nbPlaquettesCarton', e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                errors.nbPlaquettesCarton ? 'border-red-500' : 'border-gray-300'
              }`}
              min="1"
            />
            {errors.nbPlaquettesCarton && <p className="text-red-500 text-xs mt-1">{errors.nbPlaquettesCarton}</p>}
          </div>

          <div>
            <label htmlFor="edit-prixVente" className="block text-sm font-medium text-gray-700 mb-1">
              Prix vente/plaquette (FCFA)
            </label>
            <input
              type="number"
              id="edit-prixVente"
              value={formData.prixVentePlaquette}
              onChange={(e) => handleInputChange('prixVentePlaquette', e.target.value)}
              className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                errors.prixVentePlaquette ? 'border-red-500' : 'border-gray-300'
              }`}
              min="0"
              step="0.01"
            />
            {errors.prixVentePlaquette && <p className="text-red-500 text-xs mt-1">{errors.prixVentePlaquette}</p>}
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-200 flex items-center justify-center gap-2"
            >
              <Save size={16} />
              Sauvegarder
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};