import React, { useState } from 'react';
import { Header } from './components/Header';
import { MedicationForm } from './components/MedicationForm';
import { MedicationTable } from './components/MedicationTable';
import { EditMedicationModal } from './components/EditMedicationModal';
import { useMedications } from './hooks/useMedications';
import { Medication } from './types/medication';

function App() {
  const { medications, addMedication, updateMedication, deleteMedication } = useMedications();
  const [editingMedication, setEditingMedication] = useState<Medication | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const handleEditMedication = (medication: Medication) => {
    setEditingMedication(medication);
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = (updatedMedication: Medication) => {
    updateMedication(updatedMedication);
    setIsEditModalOpen(false);
    setEditingMedication(null);
  };

  const handleCloseModal = () => {
    setIsEditModalOpen(false);
    setEditingMedication(null);
  };

  const handleDeleteMedication = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce médicament ?')) {
      deleteMedication(id);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MedicationForm onAddMedication={addMedication} />
        
        <MedicationTable
          medications={medications}
          onEditMedication={handleEditMedication}
          onDeleteMedication={handleDeleteMedication}
        />

        <EditMedicationModal
          medication={editingMedication}
          isOpen={isEditModalOpen}
          onClose={handleCloseModal}
          onSave={handleSaveEdit}
        />
      </main>
    </div>
  );
}

export default App;