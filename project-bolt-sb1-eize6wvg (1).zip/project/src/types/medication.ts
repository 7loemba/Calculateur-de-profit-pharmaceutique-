export interface Medication {
  id: string;
  produit: string;
  prixGros: number;
  nbPlaquettesCarton: number;
  prixAchatPlaquette: number;
  prixVentePlaquette: number;
  beneficePlaquette: number;
  beneficeCarton: number;
}