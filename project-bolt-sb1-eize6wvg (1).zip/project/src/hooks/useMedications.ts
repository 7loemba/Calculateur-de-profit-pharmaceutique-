import { useState, useCallback } from 'react';
import { Medication } from '../types/medication';

const initialMedications: Medication[] = [
  {
    id: '1',
    produit: 'Ibucap forte',
    prixGros: 2500,
    nbPlaquettesCarton: 10,
    prixAchatPlaquette: 250,
    prixVentePlaquette: 400,
    beneficePlaquette: 150,
    beneficeCarton: 1500,
  },
  {
    id: '2',
    produit: 'Paracétamol',
    prixGros: 500,
    nbPlaquettesCarton: 10,
    prixAchatPlaquette: 50,
    prixVentePlaquette: 100,
    beneficePlaquette: 50,
    beneficeCarton: 500,
  },
];

export const useMedications = () => {
  const [medications, setMedications] = useState<Medication[]>(initialMedications);

  const addMedication = useCallback((newMedication: Omit<Medication, 'id'>) => {
    const medication: Medication = {
      ...newMedication,
      id: Date.now().toString(),
    };
    setMedications(prev => [...prev, medication]);
  }, []);

  const updateMedication = useCallback((updatedMedication: Medication) => {
    setMedications(prev =>
      prev.map(med => med.id === updatedMedication.id ? updatedMedication : med)
    );
  }, []);

  const deleteMedication = useCallback((id: string) => {
    setMedications(prev => prev.filter(med => med.id !== id));
  }, []);

  return {
    medications,
    addMedication,
    updateMedication,
    deleteMedication,
  };
};